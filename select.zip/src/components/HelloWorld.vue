<template>
  <div class="hello">
<select2/>
  </div>
</template>

<script>
import select2 from '@/components/select2'

export default {
  name: 'HelloWorld',
  components:{
    select2
  },
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
